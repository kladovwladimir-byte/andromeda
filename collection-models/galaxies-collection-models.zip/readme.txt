This archive contains a collection of galaxiy models which can be loaded to the GalaxyModel program. Photos of galaxies should be loaded separately, its URLs are included into .gal files.
To read the instruction on using the GalaxyModel, download it at github:

https://github.com/kladovwladimir-byte/andromeda

Vladimir Kladov, 2026, Novosibirsk.